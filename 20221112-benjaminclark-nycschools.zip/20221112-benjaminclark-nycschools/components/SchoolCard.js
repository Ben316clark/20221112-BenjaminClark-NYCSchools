import * as React from 'react';
import { useEffect, useState } from 'react';
import {ActivityIndicator, FlatList, Text, View, StyleSheet, Image } from 'react-native';

export default function SchoolCard() { 
   const [isLoading, setLoading] = useState(true);
   const [data, setData] = useState([]);
  const getSchoolNamesFromApi = async () =>{
    try {
      const response = await fetch ('https://data.cityofnewyork.us/resource/s3k6-pzi2.json');

    const json = await response.json();
    setData(json.school_name);
    return json.school_name;}
    catch(error){
      console.error(error);
    } finally { setLoading(false);
    }
  }
  useEffect(() => {
    getSchoolNamesFromApi();},[]);
  

  return (
    <View style={styles.container}>
    {isLoading ? <ActivityIndicator/> : (
      <FlatList data={data}
      keyExtractor={({id},index)=> id}
      renderItem={({item})=> ( <Text style={styles.paragraph}>
        School Name: {school_name}
      </Text>)}
      /> )}
      

    </View>
  );
  }
  const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  
});